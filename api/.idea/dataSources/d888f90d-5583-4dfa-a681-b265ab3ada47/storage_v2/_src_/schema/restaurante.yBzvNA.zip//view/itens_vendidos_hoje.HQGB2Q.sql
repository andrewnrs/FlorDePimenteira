create view itens_vendidos_hoje as
select sum(`ip`.`qtd`) AS `qtd`, `ic`.`nome` AS `nome`
from (`restaurante`.`item_pedido` `ip`
         join `restaurante`.`item_cardapio` `ic`)
where (`ic`.`id` = `ip`.`item_cardapio_id`)
group by `ip`.`item_cardapio_id`;

