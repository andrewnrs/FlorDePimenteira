create definer = uroot@`%` trigger Inicializa_Conta_Valor_Total
    after insert
    on item_pedido
    for each row
BEGIN
	DECLARE valor_total decimal(10,2);
    
    select total into valor_total from valor_total_do_pedido v where v.pedido_id = NEW.pedido_id; 
	UPDATE pedido SET total = valor_total where pedido.id = new.pedido_id;
END;

