create view valor_total_por_item_do_pedido as
select sum((`restaurante`.`item_pedido`.`valor_unit` * `restaurante`.`item_pedido`.`qtd`)) AS `total`,
       `restaurante`.`item_pedido`.`item_cardapio_id`                                      AS `item_cardapio_id`
from `restaurante`.`item_pedido`
group by `restaurante`.`item_pedido`.`pedido_id`, `restaurante`.`item_pedido`.`item_cardapio_id`;

