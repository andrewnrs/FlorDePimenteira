create definer = uroot@`%` trigger Estabelece_Valor
    before insert
    on item_pedido
    for each row
BEGIN
	DECLARE valor_item decimal(10,2);
    
    select valor_vigente INTO valor_item
    from item_cardapio where item_cardapio.id=NEW.item_cardapio_id;

    set NEW.valor_unit  = valor_item;
    
END;

