create definer = uroot@`%` trigger Atualiza_Horario_Entregue
    before update
    on item_pedido
    for each row
BEGIN
	DECLARE valor_total decimal(10,2);
	IF(OLD.estado <> NEW.estado) THEN
		IF(NEW.estado = 'ENTREGUE') THEN
			set NEW.data_entregue  = CURRRENT_TIMESTAMP();
		END IF;
	END IF;
END;

